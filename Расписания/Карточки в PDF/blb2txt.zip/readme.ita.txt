Balabolka (Text Extract Utility), version 1.76
Copyright (c) 2013-2019 Ilya Morozov
All Rights Reserved

WWW: http://balabolka.site/it/btext.htm
E-mail: crossa@list.ru

Licenza: gratuita
Sistema operativo: Microsoft Windows XP/Vista/7/8/10


Il programma permette di estrarre il testo da vari tipi di file.
Il testo estratto pu� essere riunito in un singolo file e/o suddiviso in vari file.
Al testo possono essere applicate le regole dei dizionari di correzione della pronuncia del programma Balabolka.
Formati supportati per i file di ingresso: AZW, AZW3, CHM, DjVu (DjVu+OCR), DOC, DOCX, EPUB, FB2 (FB2.ZIP, FBZ), FB3, HTML, LIT, MHT, MOBI, ODP, ODS, ODT, PDB, PDF, PPT, PPTX, PRC, RTF, TCR, TXT, WPD, WRI, XLS, XLSX.
L'interfaccia IFilter verr� utilizzata per i file con estensione sconosciuta.


*** Riga di comando ***

blb2txt [opzioni ...]


*** Opzioni della riga di comando ***

-f <nome_file>
   Nome del file o specificazione del gruppo di file da cui si estrae il testo. La riga di comando pu� contenere varie opzioni [-f].

-v <nome_cartella>
   Nome della cartella in cui salvare il file con il testo estratto.

-p <testo>
   Schema del nome di file con il testo estratto (ad esempio "Documento"). In sua assenza viene usato il nome del file in ingresso.
   Usare la variabile %FirstLine% per inserire la prima riga di testo nel nome del file di uscita.
   Use the %Header% variable to insert the chapter title to the output file name.
   Usare la variabile %Number% per cambiare la posizione del numero di sequenza entro il nome del file di uscita.

-out <nome_file>
   Sets the full name for output file. The option is recommended to specify only when the utility is used as a part of other software.
   If the utility is used for custom document import,  the external program runs the utility from a command line and passes the full name of a text file to create.

-i
   Legge il testo dal flusso in ingresso (STDIN). Se si specifica questa opzione, l'opzione [-f] � ignorata.

-o
   Scrive il testo estratto nel flusso di uscita (STDOUT). Se si specifica questa opzione, le opzioni [-v] e [-p] sono ignorate.

-u
   Riunisce il testo di vari file in un file singolo.

-b
   Aggiunge un numero progressivo all'inizio del nome del file di uscita.

-a
   Aggiunge un numero progressivo alla fine del nome del file di uscita.

-n <numero_intero>
   Imposta il numero iniziale della sequenza dei file di uscita. Il valore predefinito � 1.

-e <codifica>
   Codifica dei file con il testo estratto ("ansi", "utf8" o "unicode"). Il valore predefinito � "ansi".

-t <numero_intero>
   Divide il testo destinazione specificando la grandezza delle parti (espressa in kilobyte).

-k <parola_chiave>
   Divide il testo in ingresso sulla particolare parola chiave. L'opzione distingue maiuscole/minuscole. La riga di comando pu� contenere varie opzioni [-k].

-r <parola_chiave>
   Divide il testo in ingresso sulla parola chiave e la rimuove. L'opzione distingue maiuscole/minuscole. La riga di comando pu� contenere varie opzioni [-r].

-w
   Divide il testo su due righe vuote consecutive.

-l
   Divide il testo sulle righe in cui tutte le lettere sono maiuscole.

-c
   Divide il testo secondo un indice. L'applicazione estrae le posizioni di inizio capitolo dal testo in ingresso (if the file contains such information).

-toc
   Generates a table of contents and splits text. L'applicazione divide il testo estratto per parole chiave (come "capitolo").
   If the option is used together with the option [-c], the application will try to extract a table of contents from the document; if it fails, a new table of contents will be generated.

-m <numero_intero>
   Ignora l'inizio di capitolo se la grandezza del capitolo precedente � minore del valore specificato (in caratteri). L'opzione si usa insieme con l'opzione [-c] e [-toc].

-hh <testo>
   Inserts text in front of headings (for example: ## Chapter 1).

-d <nome_file>
   Usa un dizionario per la correzione della pronuncia (*.BXD, *.DIC o *.REX). La riga di comando pu� contenere varie opzioni [-d].

-if
   Usa l'interfaccia IFilter per estrarre il testo. Se non funziona, il metodo predefinito verr� usato dall'applicazione.

-g <nome_cartella>
   Sets the name of output folder for saving of images from a document.

-cvr <nome_cartella>
   Sets the name of output folder for saving of a book cover image.

-pwd <testo>
   Specifica la password per estrarre il testo da un file PDF cifrato.

-? o -h
   Mostra l'elenco delle opzioni disponibili nella riga di comando.

--remove-spaces o -rs
   Elimina gli spazi superflui (due o pi� spazi bianchi consecutivi, spazi indivisibili).

--remove-hyphens o -rh
   Elimina i trattini di sillabazione alla fine delle righe del testo.

--remove-linebreaks o -rl
   Elimina le interruzioni di riga entro i paragrafi.

--remove-empty-lines o -rm
   Elimina le righe vuote.

--replace-empty-lines o -rp
   Sostituisce pi� righe vuote con una singola riga vuota.

--remove-square-brackets o -rsb
   Elimina il testo racchiuso fra [parentesi quadre].

--remove-curly-brackets o -rcb
   Elimina il testo racchiuso fra {parentesi graffe}.

--remove-angle-brackets o -rab
   Elimina il testo racchiuso fra <parentesi angolate>.

--remove-round-brackets o -rrb
   Removes text in (round brackets).

--remove-comments o -rc
   Remove comments. Single-line comments start with // and continue until the end of the line. Multiline comments start with /* and end with */.

--remove-page-numbers o -rpn
   Removes page numbers (it may be useful for DjVu/PDF files).

--fix-ocr-errors o -ocr
   Corregge gli errori dovuti all'OCR (solo per lingue con alfabeto cirillico).

--fix-letter-spacing o -ls
   Corregge la spaziatura fra lettere nelle parole (ad esempio: s p a c e, _w_o_r_d).

--skip-summary o -ss
   Salta il riassunto (detto anche "annotation"), quando l'applicazione estrae il testo dai file FB2/FB3.

--skip-notes o -sn
   Salta le note, quando l'applicazione estrae il testo dai file DOCX/FB2/FB3/ODT.

--include-notes <numero_intero> o -in <numero_intero>
   Includes notes inside text, when the application extracts text from DOCX/FB2/FB3/ODT files.
   Possible values for the integer parameter:
   0 - removes links to notes from text,
   1 - keeps default positions of notes inside text (this value is used by default),
   2 - places notes at the end of sentences,
   3 - places notes at the end of paragraphs.

--csv-comma
   Le colonne sono separate da una virgola, quando l'applicazione estrae i dati dai file XLS/XLSX/ODS (delimitatore predefinito per i file CSV).

--csv-semicolon
   Le colonne sono separate da un punto e virgola, quando l'applicazione estrae i dati da file XLS/XLSX/ODS.

--csv-space
   Le colonne sono separate da uno spazio vuoto, quando l'applicazione estrae i dati da file XLS/XLSX/ODS.

--csv-tab
   Le colonne sono separate da un carattere tab, quando l'applicazione estrae i dati da file XLS/XLSX/ODS.

--csv-double-quote
   Usa virgolette doppie, se un campo deve essere virgolettato (esportazione dai file XLS/XLSX/ODS).

--csv-single-quote
   Usa virgolette singole, se un campo deve essere virgolettato (esportazione dai file XLS/XLSX/ODS).

--eml-save <nome_cartella>
   Extracts attachments from EML files and saves to a specified folder.

--eml-att
   Extracts the list of attachments from EML files (names of files attached to the message).

--eml-cc
   Extracts the header field "Cc" from EML files ("carbon copy"; it specifies additional recipients of the message).

--eml-date <date_format>
   Extracts the header field "Date" from EML files (the local time and date when the message was composed and sent). A date format are defined by specifiers (such as "d", "m", "y", etc.). For example: "dd.mm.yyyy hh:nn:ss".

--eml-from
   Extracts the header field "From" from EML files (the email address, and optionally the name of the author).

--eml-org
   Extracts the header field "Organization" from EML files (the name of the organization through which the sender of the message has net access).

--eml-rt
   Extracts the header field "Reply-To" from EML files (the address for replies to go to).

--eml-subj
   Extracts the header field "Subject" from EML files (the subject of the message).

--eml-to
   Extracts the header field "To" from EML files (the email address, and optionally the name of the message's recipient).


*** Esempi ***

blb2txt -f "d:\Docs\Libro.doc" -v "d:\Text\"

blb2txt -f "d:\Docs\Libro.doc" -out "d:\Text\Libro.txt"

blb2txt -f "d:\Docs\*.doc" -f "d:\Docs\*.rtf" -v "d:\Text\" -e utf8 --replace-empty-lines

blb2txt -f "d:\Docs\*.*" -v "d:\Text\" -p "Document" -u

blb2txt -f "d:\Docs\1.doc" -v "d:\Text\" -p "Document" -a -n 20 -t 100

blb2txt -f "d:\Book\libro.fb2" -v "d:\Text\" -p "Libro" -k "CAPITOLO" -k "SOMMARIO"

blb2txt -f "d:\Book\libro.epub" -v "d:\Text\" -p "Libro" -r "###"

blb2txt -f "d:\Book\book.fb2" -v "d:\Text\" -p "%Number% - %Header%" -c -m 1024

blb2txt -f "d:\Docs\libro.doc" -v "d:\Text\" -d "d:\rex\regole.rex" -d "d:\dic\regole.dic" --remove-spaces --remove-linebreaks

blb2txt -i -o --remove-spaces --remove-linebreaks --replace-empty-lines


*** File di configurazione ***

Le opzioni della riga di comando possono essere registrate nel file "blb2txt.cfg" nella stessa cartella del programma.

Esempio di file di configurazione:
=====================
-f d:\Docs\*.rtf
-f d:\Books\*.epub
-f d:\Books\*.fb2
-v d:\Text
-b
-n 1
-t 25
-e utf8
-d d:\Dict\regole.bxd
--remove-spaces
--remove-linebreaks
--replace-empty-lines
=====================

Il programma pu� combinare le opzioni del file di configurazione con quelle della riga di comando.


*** Operazioni ***

Il programma compie le operazioni nell'ordine seguente:

1.  Estrarre il testo dal/dai file in ingresso.
2.  Formattare il testo: eliminare spazi superflui, interruzioni di riga, etc. (se le opzioni sono specificate).
3.  Riunire pi� file in un singolo file (se l'opzione � specificata).
4.  Dividere il testo (se le opzioni sono specificate).
5.  Applicare le regole per la correzione della pronuncia (se l'opzione � specificata).
6.  Registrare il/i file su disco.


*** Licenza ***

Diritto di utilizzo non commerciale del programma:
- per le persone fisiche: senza alcuna restrizione;
- per le persone giuridiche: soggetto alle restrizioni riportate nel contratto di licenza del software Balabolka.

L'utilizzo commerciale richiede la previa autorizzazione del titolare del copyright.

###
