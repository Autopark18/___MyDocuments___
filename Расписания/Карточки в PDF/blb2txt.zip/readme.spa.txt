Balabolka (programa para extraer texto del fichero), versi�n 1.76
Copyright (c) 2013-2019 Ilya Morozov
All Rights Reserved

WWW: http://balabolka.site/es/btext.htm
E-mail: crossa@list.ru

Licencia: Gratuito (Freeware)
Sistema operativo: Microsoft Windows XP/Vista/7/8/10


El programa est� dise�ado para extraer textos de ficheros de diferentes formatos.
El texto extra�do puede ser reunido en un solo fichero y / o distribuido en varios ficheros.
Al texto se le puede aplicar las reglas de los diccionarios de correcci�n de pronunciaci�n del programa Balabolka.
Se soportan los siguientes formatos de fichero: AZW, AZW3, CHM, DjVu (DjVu+OCR), DOC, DOCX, EPUB, FB2 (FB2.ZIP, FBZ), FB3, HTML, LIT, MHT, MOBI, ODP, ODS, ODT, PDB, PDF, PPT, PPTX, PRC, RTF, TCR, TXT, WPD, WRI, XLS, XLSX.
The IFilter interface will be used for files with unknown extensions.


*** L�nea de comandos ***

blb2txt [opciones ...]


*** Opciones del comando ***

-f <nombre_de_fichero>
   El nombre de fichero o una m�scara para los nombres de de los ficheros de los cuales se extrae el texto. La l�nea de comandos puede contener varias opciones [-f].

-v <nombre_de_carpeta>
   Nombre de la carpeta para salvar el fichero con el texto extra�do.

-p <texto>
   Plantilla para el nombre del fichero con el texto extra�do (por ejemplo, "Documento de texto"). Si no se especifica la opci�n se usa el nombre del fichero de origen.
   Use the %FirstLine% variable to insert the first line of text to the output file name.
   Use the %Header% variable to insert the chapter title to the output file name.
   Use the %Number% variable to change the position of the sequence number inside the output file name.

-out <nombre_de_fichero>
   Sets the full name for output file. The option is recommended to specify only when the utility is used as a part of other software.
   If the utility is used for custom document import,  the external program runs the utility from a command line and passes the full name of a text file to create.

-i
   Leer el texto del flujo de entrada est�ndar (STDIN). Si se especifica la opci�n, se ignora la opci�n [-f].

-o
   Inscribir el texto en el flujo de salida est�ndar (STDOUT). Si se especifica la opci�n, se ignoran las opciones [-v] y [-p].

-u
   Reunir textos de varios ficheros en un solo fichero.

-b
   A�adir el n�mero de orden antes del nombre del fichero.

-a
   A�adir el n�mero de orden despu�s del nombre del fichero.

-n <entero>
   Establecer el n�mero de orden inicial del fichero. El valor predeterminado es 1.

-e <codificaci�n>
   Codificaci�n del fichero con el texto extra�do ("ansi", "utf8" o "unicode"). El valor predeterminado es "ansi".

-t <entero>
   Especificar el modo de partici�n del texto: uso de un tama�o predeterminado del fichero. El n�mero corresponde al n�mero de kilobytes.

-k <palabra_clave>
   Especificar el modo de partici�n del texto: b�squeda de palabra clave en el fichero de origen. Esta opci�n distingue entre may�sculas y min�sculas. La l�nea de comandos puede contener varias opciones [-k].

-r <palabra_clave>
   Dividir el texto con la palabra clave y retirarla del texto. Esta opci�n distingue entre may�sculas y min�sculas. La l�nea de comandos puede contener varias opciones [-r].

-w
   Especificar el modo de partici�n del texto: buscar dos l�neas en blanco seguidas.

-l
   Especificar el modo de partici�n del texto: buscar el texto donde todas las letras son may�sculas.

-c
   Splits text by a table of contents. The application extracts positions of chapter beginnings from the input file (if the file contains such information).

-toc
   Generates a table of contents and splits text. The application splits the extracted text by keywords (like "cap�tulo").
   If the option is used together with the option [-c], the application will try to extract a table of contents from the document; if it fails, a new table of contents will be generated.

-m <entero>
   Ignores the chapter beginning if the size of the previous chapter is less than the specified value (in characters). The option is used together with the option [-c] or [-toc].

-hh <texto>
   Inserts text in front of headings (for example: ## Chapter 1).

-d <nombre_de_fichero>
   Usar el diccionario para la correcci�n de la pronunciaci�n (fichero con extensi�n *.BXD, *.DIC o *.REX). La l�nea de comandos puede contener varios par�metros [-d].

-if
   Uses IFilter interface to extract text. If this fails, the default method will be used by the application.

-g <nombre_de_carpeta>
   Sets the name of output folder for saving of images from a document.

-cvr <nombre_de_carpeta>
   Sets the name of output folder for saving of a book cover image.

-pwd <texto>
   Designar una contrase�a para sacar el texto del fichero en formato PDF.

-? o -h
   Mostrar descripci�n de la l�nea de comandos.

--remove-spaces o -rs
   Eliminar espacios en blanco (dos o m�s espacios seguidos, espacios sin separaci�n).

--remove-hyphens o -rh
   Eliminar guiones en los extremos de l�neas en el texto.

--remove-linebreaks o -rl
   Eliminar saltos de l�nea dentro de un p�rrafo.

--remove-empty-lines o -rm
   Eliminar todas las l�neas en blanco.

--replace-empty-lines o -rp
   Reemplazar m�ltiples l�neas en blanco una sola l�nea en blanco.

--remove-square-brackets o -rsb
   Eliminar el texto entre [corchetes].

--remove-curly-brackets o -rcb
   Elimine el texto entre {llaves}.

--remove-angle-brackets o -rab
   Eliminar el texto entre <par�ntesis angulares>.

--remove-round-brackets o -rrb
   Removes text in (round brackets).

--remove-comments o -rc
   Borra los comentarios. Los comentarios de una sola l�nea comienzan con // y contin�an hasta el final de la l�nea. Los comentarios de varias l�neas comienzan con /* y terminan con */.

--remove-page-numbers o -rpn
   Removes page numbers (it may be useful for DjVu/PDF files).

--fix-ocr-errors o -ocr
   Corregir errores ocurridos en OCR (s�lo para idiomas con alfabeto cir�lico).

--fix-letter-spacing o -ls
   Fixes letter-spacing in words (for example: s p a c e, _w_o_r_d).

--skip-summary o -ss
   Skips a summary, when the application extracts text from FB2/FB3 files.

--skip-notes o -sn
   Skips notes, when the application extracts text from DOCX/FB2/FB3/ODT files.

--include-notes <entero> o -in <entero>
   Includes notes inside text, when the application extracts text from DOCX/FB2/FB3/ODT files.
   Possible values for the integer parameter:
   0 - removes links to notes from text,
   1 - keeps default positions of notes inside text (this value is used by default),
   2 - places notes at the end of sentences,
   3 - places notes at the end of paragraphs.

--csv-comma
   Columns are separated by a comma, when the application extracts data from XLS/XLSX/ODS files (default delimiter for CSV files).

--csv-semicolon
   Columns are separated by a semicolon, when the application extracts data from XLS/XLSX/ODS files.

--csv-space
   Columns are separated by a blank space, when the application extracts data from XLS/XLSX/ODS files.

--csv-tab
   Columns are separated by a tab, when the application extracts data from XLS/XLSX/ODS files.

--csv-double-quote
   Uses double-quote characters, if a field must be quoted (export from XLS/XLSX/ODS files).

--csv-single-quote
   Uses single-quote characters, if a field must be quoted (export from XLS/XLSX/ODS files).

--eml-save <nombre_de_carpeta>
   Extracts attachments from EML files and saves to a specified folder.

--eml-att
   Extracts the list of attachments from EML files (names of files attached to the message).

--eml-cc
   Extracts the header field "Cc" from EML files ("carbon copy"; it specifies additional recipients of the message).

--eml-date <date_format>
   Extracts the header field "Date" from EML files (the local time and date when the message was composed and sent). A date format are defined by specifiers (such as "d", "m", "y", etc.). For example: "dd.mm.yyyy hh:nn:ss".

--eml-from
   Extracts the header field "From" from EML files (the email address, and optionally the name of the author).

--eml-org
   Extracts the header field "Organization" from EML files (the name of the organization through which the sender of the message has net access).

--eml-rt
   Extracts the header field "Reply-To" from EML files (the address for replies to go to).

--eml-subj
   Extracts the header field "Subject" from EML files (the subject of the message).

--eml-to
   Extracts the header field "To" from EML files (the email address, and optionally the name of the message's recipient).


*** Ejemplos ***

blb2txt -f "d:\Docs\libro.doc" -v "d:\Texto\"

blb2txt -f "d:\Docs\libro.doc" -out "d:\Texto\libro.txt"

blb2txt -f "d:\Docs\*.doc" -f "d:\Docs\*.rtf" -v "d:\Text\" -e utf8 --replace-empty-lines

blb2txt -f "d:\Docs\*.*" -v "d:\Texto\" -p "Documento" -u

blb2txt -f "d:\Docs\1.doc" -v "d:\Texto\" -p "Documento" -a -n 20 -t 100

blb2txt -f "d:\Book\libro.fb2" -v "d:\Texto\" -p "Libro" -k "CAPITULO" -k "Indice"

blb2txt -f "d:\Book\libro.epub" -v "d:\Texto\" -p "Libro" -r "###"

blb2txt -f "d:\Book\libro.fb2" -v "d:\Texto\" -p "%Number% - %Header%" -c -m 1024

blb2txt -i -o --remove-spaces --remove-linebreaks --replace-empty-lines


*** Archivo de configuraci�n ***

Se puede guardar el archivo de configuraci�n "blb2txt.cfg" en la misma carpeta que la aplicaci�n de consola.

Un ejemplo del contenido del archivo:
=====================
-f d:\Docs\*.rtf
-f d:\Books\*.epub
-f d:\Books\*.fb2
-v d:\Text
-b
-n 1
-t 25
-e utf8
-d d:\Dict\rules.bxd
--remove-spaces
--remove-linebreaks
--replace-empty-lines
=====================

El programa puede combinar opciones del fichero de configuraci�n y de la l�nea de comandos.


*** Operaciones ***

El programa cumple operaciones en el orden siguiente:

1.  Extraer el texto del fichero.
2.  Formatear el texto: eliminar espacios extra, saltos de l�nea, etc. (si tales opciones est�n especificadas).
3.  Reunir textos en un solo fichero (si tal opci�n est� especificada).
4.  Dividir el texto en partes (si tales opciones est�n especificadas).
5.  Aplicar las reglas de correcci�n de pronunciaci�n (si tales opciones est�n especificadas).
6.  Salvar el fichero o los ficheros en el disco.


*** Licencia ***

Derecho al uso no comercial del programa:
- para las personas naturales: sin ning�n tipo de restricciones;
- para las personas jur�dicas: sujeto a las restricciones que figuran en el "Contrato de licencia" del software Balabolka.

El uso comercial del programa s�lo se permite con previa autorizaci�n del titular de derechos de autor.

###