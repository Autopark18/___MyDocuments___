﻿Balabolka (инструмент за извличане на текст), версия 1.76
Авторски права (c) 2013-2019 Илия Морозов
Всички права запазени

Уебсайт: http://balabolka.site/bg/btext.htm
Е-поща: crossa@list.ru

Лиценз: Безплатен (Freeware)
Операционни системи: Microsoft Windows XP/Vista/7/8/10


Програмата позволява извличането на текста от разни типове файлове.
Извлеченият текст може да бъде обединен в един общ файл или/и разцепен на няколко файла.
Списъкът с правилата от Balabolka за корекция на произношението може да бъде приложен върху текста.
За вход се поддържат следните файлови формати: AZW, AZW3, CHM, DjVu (DjVu+OCR), DOC, DOCX, EPUB, FB2 (FB2.ZIP, FBZ), FB3, HTML, LIT, MHT, MOBI, ODP, ODS, ODT, PDB, PDF, PPT, PPTX, PRC, RTF, TCR, TXT, WPD, WRI, XLS, XLSX.
The IFilter interface will be used for files with unknown extensions.


*** Начин на употреба ***

blb2txt [опции ...]


*** Опции за командния ред ***

-f <файлов_филтър>
   Задава името на входния файл или маската за групата от входни файлове. Командния ред може да съдържа повече от една [-f] опция.

-v <име_на_папка>
   Задава името на папката за запис на изходните текстови файлове.

-p <текст>
   Задава образеца за име на изходния файл (например: "Текстов Документ"). Ако не е зададено, ще бъде използвано името на входния файл.
   Използвайте променливата %FirstLine%, за да вмъкнете първия ред от текста в името на изходния файл.
   Use the %Header% variable to insert the chapter title to the output file name.
   Use the %Number% variable to change the position of the sequence number inside the output file name.

-out <име_на_файл>
   Sets the full name for output file. The option is recommended to specify only when the utility is used as a part of other software.
   If the utility is used for custom document import,  the external program runs the utility from a command line and passes the full name of a text file to create.

-i
   Прочита текста от STDIN. Ако опцията е зададена, опцията [-f] бива игнорирана.

-o
   Записва текста в STDOUT. Ако опцията е зададена, опциите [-v] и [-p] биват игнорирани.

-u
   Обединява всички входни файлове в един общ изходен такъв.

-b
   Добавя нарастващо число в началото на имената на изходните файлове.

-a
   Добавя нарастващо число в края на имената на изходните файлове.

-n <целочислена_стойност>
   Задава началното число за имената на изходните файлове. Стойността по подразбиране е 1.

-e <кодиране>
   Задава кодировката на изходните файлове ("ansi", "utf8" или "unicode"). Стойността по подразбиране е "ansi".

-t <целочислена_стойност>
   Разцепва текста на части на база размера на изходните файлове (в килобайти).

-k <ключова_дума>
   Разцепва текста на базата на специална ключова дума във входния файл. За опцията е от значение дали се използват малки или главни букви. Командния ред може да съдържа повече от една [-k] опция.

-r <ключова_дума>
   Разцепва текста на базата на ключова дума, и я премахва от изходните файлове. За опцията е от значение дали се използват малки или главни букви. Командния ред може да съдържа повече от една [-r] опция.

-w
   Разцепва текста на базата на два последователни празни реда.

-l
   Разцепва текста на базата на редове, на които всички букви са главни.

-c
   Splits text by a table of contents. The application extracts positions of chapter beginnings from the input file (if the file contains such information).

-toc
   Generates a table of contents and splits text. The application splits the extracted text by keywords (like "глава" or "том").
   If the option is used together with the option [-c], the application will try to extract a table of contents from the document; if it fails, a new table of contents will be generated.

-m <целочислена_стойност>
   Ignores the chapter beginning if the size of the previous chapter is less than the specified value (in characters). The option is used together with the option [-c] or [-toc].

-hh <текст>
   Inserts text in front of headings (for example: ## Chapter 1).

-d <име_на_файл>
   Използва речник за корекция на произношението (*.BXD, *.DIC или *.REX). Командния ред може да съдържа повече от една [-d] опция.

-if
   Uses IFilter interface to extract text. If this fails, the default method will be used by the application.

-g <име_на_папка>
   Sets the name of output folder for saving of images from a document.

-cvr <име_на_папка>
   Sets the name of output folder for saving of a book cover image.

-pwd <текст>
   Задава паролата за шифрованите PDF файлове.

-? или -h
   Извежда списък с възможните опции за командния ред.

--remove-spaces или -rs
   Премахва излишните интервали (два или повече последователни интервала, непрекъсващи интервали).

--remove-hyphens или -rh
   Премахва тиретата в края на редовете в текста.

--remove-linebreaks или -rl
   Премахва знаците за нов ред в абзаците (параграфите).

--remove-empty-lines или -rm
   Премахва празните редове.

--replace-empty-lines или -rp
   Замества два или повече празни реда с един такъв.

--remove-square-brackets или -rsb
   Премахва текста в [квадратни скоби].

--remove-curly-brackets или -rcb
   Премахва текста във {вълнообразни скоби}.

--remove-angle-brackets или -rab
   Премахва текста в <ъглови скоби>.

--remove-round-brackets или -rrb
   Removes text in (round brackets).

--remove-comments или -rc
   Remove comments. Single-line comments start with // and continue until the end of the line. Multiline comments start with /* and end with */.

--remove-page-numbers или -rpn
   Removes page numbers (it may be useful for DjVu/PDF files).

--fix-ocr-errors или -ocr
   Поправя OCR грешки (само за езици с кирилска азбука).

--fix-letter-spacing или -ls
   Fixes letter-spacing in words (for example: п р а з н и н а, _д_у_м_а).

--skip-summary или -ss
   Skips a summary, when the application extracts text from FB2/FB3 files.

--skip-notes или -sn
   Skips notes, when the application extracts text from DOCX/FB2/FB3/ODT files.

--include-notes <целочислена_стойност> или -in <целочислена_стойност>
   Includes notes inside text, when the application extracts text from DOCX/FB2/FB3/ODT files.
   Possible values for the integer parameter:
   0 - removes links to notes from text,
   1 - keeps default positions of notes inside text (this value is used by default),
   2 - places notes at the end of sentences,
   3 - places notes at the end of paragraphs.

--csv-comma
   Columns are separated by a comma, when the application extracts data from XLS/XLSX/ODS files (default delimiter for CSV files).

--csv-semicolon
   Columns are separated by a semicolon, when the application extracts data from XLS/XLSX/ODS files.

--csv-space
   Columns are separated by a blank space, when the application extracts data from XLS/XLSX/ODS files.

--csv-tab
   Columns are separated by a tab, when the application extracts data from XLS/XLSX/ODS files.

--csv-double-quote
   Uses double-quote characters, if a field must be quoted (export from XLS/XLSX/ODS files).

--csv-single-quote
   Uses single-quote characters, if a field must be quoted (export from XLS/XLSX/ODS files).

--eml-save <име_на_папка>
   Extracts attachments from EML files and saves to a specified folder.

--eml-att
   Extracts the list of attachments from EML files (names of files attached to the message).

--eml-cc
   Extracts the header field "Cc" from EML files ("carbon copy"; it specifies additional recipients of the message).

--eml-date <date_format>
   Extracts the header field "Date" from EML files (the local time and date when the message was composed and sent). A date format are defined by specifiers (such as "d", "m", "y", etc.). For example: "dd.mm.yyyy hh:nn:ss".

--eml-from
   Extracts the header field "From" from EML files (the email address, and optionally the name of the author).

--eml-org
   Extracts the header field "Organization" from EML files (the name of the organization through which the sender of the message has net access).

--eml-rt
   Extracts the header field "Reply-To" from EML files (the address for replies to go to).

--eml-subj
   Extracts the header field "Subject" from EML files (the subject of the message).

--eml-to
   Extracts the header field "To" from EML files (the email address, and optionally the name of the message's recipient).


*** Примери ***

Извличане на текста от BOOK.DOC и записване като "Нова книга.txt":

blb2txt -f "d:\Docs\book.doc" -v "d:\Text\" -p "Нова книга"


Извличане на текста от документи на Microsoft Word и RTF документи, премахване на празните редове и записване в текстови файлове с кодиране UTF-8:

blb2txt -f "d:\Docs\*.doc" -f "d:\Docs\*.rtf" -v "d:\Text\" -e utf8 --replace-empty-lines


Извличане на текста от всички файлове в указаната директория, обединяване и записване като "Документ.txt":

blb2txt -f "d:\Docs\*.*" -v "d:\Text\" -p "Документ" -u


Извличане на текста от 1.DOC, разделяне на части с размер 100 KB и записване като текстови файлове "Документ 20.txt", "Документ 21.txt", и т.н.:

blb2txt -f "d:\Docs\1.doc" -v "d:\Text\" -p "Документ" -a -n 20 -t 100


Извличане на текста от BOOK.FB2, намиране на думите "ГЛАВА" и "СЪДЪРЖАНИЕ" с цел разделяне на текста на части и записване като файлове с имената "Книга 1.txt", "Книга 2.txt", и т.н.:

blb2txt -f "d:\Book\book.fb2" -v "d:\Text\" -p "Книга" -k "ГЛАВА" -k "СЪДЪРЖАНИЕ"


Извличане на текста от BOOK.EPUB, намиране на "###" с цел разделяне на текста на части, премахване на "###" от текста и записване на всяка част като нов файл:

blb2txt -f "d:\Book\book.epub" -v "d:\Text\" -p "Книга" -r "###"


Extract text from BOOK.FB2, split by a table of contents, save files and use chapter titles as file names. New text files must not be less than one kilobyte:

blb2txt -f "d:\Book\book.fb2" -v "d:\Text\" -p "%Number% - %Header%" -c -m 1024


Получаване на текста от STDIN, премахване на излишните интервали, прекъсвания на редове и празните редове, записване на обновения текст в STDOUT:

blb2txt -i -o --remove-spaces --remove-linebreaks --replace-empty-lines


*** Конфигурационен файл ***

Опциите за командния ред могат да бъдат съхранени в конфигурационен файл "blb2txt.cfg" в същата папка, в която е и програмата.

Пример за конфигурационен файл:
=====================
-f d:\Docs\*.rtf
-f d:\Books\*.epub
-f d:\Books\*.fb2
-v d:\Text
-b
-n 1
-t 25
-e utf8
-d d:\Dict\rules.bxd
--remove-spaces
--remove-linebreaks
--replace-empty-lines
=====================

Програмата може да използва комбинация от опции от конфигурационния файл и от командния ред.


*** Действия ***

Програмата изпълнява действията в следния ред:

1.  Извлича текста от входни(я/те) файл(ове).
2.  Форматира текста: премахване на интервали, знаци за нов ред, и пр. (ако съответната опция е зададена).
3.  Обединява файловете в един общ (ако съответната опция е зададена).
4.  Разцепва текста (ако съответната опция е зададена).
5.  Прилага правилата за корекция на произношението (ако съответната опция е зададена).
6.  Съхранява изходни(я/те) файл(ове).


*** Licence ***

You are free to use and distribute software for noncommercial purposes. For commercial use or distribution, you need to get permission from the copyright holder.

###