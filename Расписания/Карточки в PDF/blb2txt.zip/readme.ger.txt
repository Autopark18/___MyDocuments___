Balabolka (Dienstprogramm zur Textextraktion), Version 1.76
Copyright (c) 2013-2019 Ilya Morozov
Alle Rechte vorbehalten

WWW: http://balabolka.site/de/btext.htm
E-mail: crossa@list.ru (nur russisch oder englisch)

Lizenzart: Freeware
Plattformen: Microsoft Windows XP/Vista/7/8/10


Das Programm erm�glicht es, Text aus verschiedenen Dateiarten zu extrahieren.
Der extrahierte Text kann in einer Datei zusammengefasst oder/und in mehrere Dateien aufgeteilt werden.
Die Liste der Aussprache-Korrektur-Regeln von Balabolka kann auf den Text angewandt werden.
Unterst�tzte Formate f�r Input-Dateien: AZW, AZW3, CHM, DjVu (DjVu+OCR), DOC, DOCX, EPUB, FB2 (FB2.ZIP, FBZ), FB3, HTML, LIT, MHT, MOBI, ODP, ODS, ODT, PDB, PDF, PPT, PPTX, PRC, RTF, TCR, TXT, WPD, WRI, XLS, XLSX.
The IFilter interface will be used for files with unknown extensions.


*** Anwendung ***

blb2txt [Optionen ...]


*** Befehlszeilen-Optionen ***

-f <Dateiname>
   Bestimmt den Namen der Eingabedatei oder die Maske f�r eine Gruppe von Eingabedateien. Die Befehlszeile kann einige Optionen enthalten [-f].

-v <Ordner>
   Bestimmt den Namen des Ausgabeordners zum Speichern der Textdateien. 

-p <Textzeile>
   Bestimmt das Muster f�r den Namen der Ausgabedatei (zum Beispiel "Textdokument"). Wenn nicht vorhanden, wird der Name der Eingabedatei verwendet.
   Verwenden Sie die Variable %FirstLine%, um die erste Textzeile als Namen der Ausgabedatei einzuf�gen.
   Verwenden Sie die Variable %Header%, um den Kapiteltitel als Namen der Ausgabedatei einzuf�gen.
   Verwenden Sie die Variable %Number%, um die Position der Sequenznummer im Namen der Ausgabedatei zu �ndern.

-out <Dateiname>
   Sets the full name for output file. The option is recommended to specify only when the utility is used as a part of other software.
   If the utility is used for custom document import,  the external program runs the utility from a command line and passes the full name of a text file to create.

-i
   Liest Text aus STDIN. Wenn diese Option gew�hlt ist, wird die Option [-f] ignoriert.

-o
   Schreibt Text in STDOUT. Wenn diese Option gew�hlt ist, werden die Optionen [-v] und [-p] ignoriert.

-u
   Kombiniert Textdateien in einer Ausgabedatei.

-b
   Setzt die Sequenznummer vor den Namen der Ausgabedatei.

-a
   Setzt die Sequenznummer hinter den Namen der Ausgabedatei.

-n <Zahl>
   Bestimmt die Start-Sequenznummer f�r die Ausgabedateien. Die Standardzahl ist 1.

-e <Kodierung>
   Bestimmt die Kodierung der Ausgabedateien ("ansi", "utf8" oder "unicode"). Standard ist "ansi".

-t <Zahl>
   Splittet Text nach Zielgr��e f�r Ausgabedateien (in Kilobytes).

-k <Schl�sselwort>
   Splittet Text vor einem speziellem Schl�sselwort in der Eingabedatei. Diese Option beachtet die Gro�- und Kleinschreibung. Die Befehlszeile kann einige Optionen enthalten [-k].

-r <Schl�sselwort>
   Splittet Text vor einem Schl�sselwort und entfernt dieses von den Ausgabedateien. Diese Option beachtet die Gro�- und Kleinschreibung. Die Befehlszeile kann einige Optionen enthalten [-r].

-w
   Splittet Text an zwei Leerzeilen in Folge.

-l
   Splittet Text vor Zeilen, die nur Gro�buchstaben enthalten.

-c
   Teilt den Text nach einem Inhaltsverzeichnis. Die Anwendung extrahiert Positionen von Kapitelanf�ngen aus der Eingabedatei (if the file contains such information).

-toc
   Generates a table of contents and splits text. Die Anwendung teilt den extrahierten Text nach Stichworten (wie "Kapitel" oder "Buch").
   If the option is used together with the option [-c], the application will try to extract a table of contents from the document; if it fails, a new table of contents will be generated.

-m <Zahl>
   Ignores the chapter beginning if the size of the previous chapter is less than the specified value (in characters). The option is used together with the option [-c] or [-toc].

-hh <Textzeile>
   Inserts text in front of headings (for example: ## Chapter 1).

-d <Dateiname>
   Verwendet ein W�rterbuch zur Aussprache-Korrektur (*.BXD, *.DIC oder *.REX). Die Befehlszeile kann einige Optionen enthalten [-d].

-if
   Verwendet die IFilter-Schnittstelle, um Text zu extrahieren. Wenn dies fehlschl�gt, wird die Standardmethode von der Anwendung verwendet.

-g <Ordner>
   Sets the name of output folder for saving of images from a document.

-cvr <Ordner>
   Sets the name of output folder for saving of a book cover image.

-pwd <Textzeile>
   Legt das Passwort f�r die verschl�sselten PDF-Dateien fest.

-? oder -h
   Druckt die Liste der verf�gbaren Befehlszeilen-Optionen.

--remove-spaces oder -rs
   Entfernt �bersch�ssige Leerzeichen (zwei oder mehr Leerzeichen in Folge, gesch�tzte Leerzeichen).

--remove-hyphens oder -rh
   Entfernt Bindestriche am Ende von Textzeilen.

--remove-linebreaks oder -rl
   Entfernt Zeilenumbr�che innerhalb von Abs�tzen.

--remove-empty-lines oder -rm
   Entfernt Leerzeilen.

--replace-empty-lines oder -rp
   Ersetzt mehrere Leerzeilen durch eine einzige Leerzeile.

--remove-square-brackets oder -rsb
   Entfernt Text in [eckigen Klammern].

--remove-curly-brackets oder -rcb
   Entfernt Text in {geschweiften Klammern}.

--remove-angle-brackets oder -rab
   Entfernt Text in <spitzen Klammern>.

--remove-round-brackets oder -rrb
   Entfernt Text in (runden Klammern).

--remove-comments oder -rc
   Remove comments. Single-line comments start with // and continue until the end of the line. Multiline comments start with /* and end with */.

--remove-page-numbers oder -rpn
   Removes page numbers (it may be useful for DjVu/PDF files).

--fix-ocr-errors oder -ocr
   Behebt OCR-Fehler (nur f�r Sprachen mit kyrillischen Alphabeten).

--fix-letter-spacing oder -ls
   Buchstabenabstand entfernen (zum Beispiel: W o r t, _T_e_x_t).

--skip-summary oder -ss
   �berspringt eine Zusammenfassung, wenn die Anwendung Text aus FB2/FB3-Dateien extrahiert.

--skip-notes oder -sn
   �berspringt Notizen, wenn die Anwendung Text aus DOCX/FB2/FB3/ODT-Dateien extrahiert.

--include-notes <Zahl> oder -in <Zahl>
   Enth�lt Anmerkungen im Text, wenn die Anwendung Text aus DOCX/FB2/FB3/ODT-Dateien extrahiert.
   M�gliche Werte f�r den Integer-Parameter:
   0 - entfernt Verkn�pfungen zu Anmerkungen aus dem Text;
   1 - beh�lt die Standardpositionen der Anmerkungen im Text bei (dieser Wert wird standardm��ig verwendet);
   2 - platziert Anmerkungen am Ende von S�tzen;
   3 - platziert Anmerkungen am Ende von Abs�tzen.

--csv-comma
   Spalten werden durch ein Komma getrennt, wenn die Anwendung Daten aus XLS/XLSX/ODS-Dateien extrahiert (Standard-Trennzeichen f�r CSV-Dateien).

--csv-semicolon
   Spalten werden durch ein Semikolon getrennt, wenn die Anwendung Daten aus XLS/XLSX/ODS-Dateien extrahiert.

--csv-space
   Spalten werden durch ein Leerzeichen getrennt, wenn die Anwendung Daten aus XLS/XLSX/ODS-Dateien extrahiert.

--csv-tab
   Spalten werden durch Tab getrennt, wenn die Anwendung Daten aus XLS/XLSX/ODS-Dateien extrahiert.

--csv-double-quote
   Verwendet doppelte Anf�hrungszeichen, wenn ein Feld zitiert werden muss (Export aus XLS/XLSX/ODS-Dateien).

--csv-single-quote
   Verwendet einfache Anf�hrungszeichen, wenn ein Feld zitiert werden muss (Export aus XLS/XLSX/ODS-Dateien).

--eml-save <Ordner>
   Extracts attachments from EML files and saves to a specified folder.

--eml-att
   Extracts the list of attachments from EML files (names of files attached to the message).

--eml-cc
   Extracts the header field "Cc" from EML files ("carbon copy"; it specifies additional recipients of the message).

--eml-date <Datumsformat>
   Extracts the header field "Date" from EML files (the local time and date when the message was composed and sent). A date format are defined by specifiers (such as "d", "m", "y", etc.). For example: "dd.mm.yyyy hh:nn:ss".

--eml-from
   Extracts the header field "From" from EML files (the email address, and optionally the name of the author).

--eml-org
   Extracts the header field "Organization" from EML files (the name of the organization through which the sender of the message has net access).

--eml-rt
   Extracts the header field "Reply-To" from EML files (the address for replies to go to).

--eml-subj
   Extracts the header field "Subject" from EML files (the subject of the message).

--eml-to
   Extracts the header field "To" from EML files (the email address, and optionally the name of the message's recipient).


*** Beispiele ***

blb2txt -f "d:\Docs\book.doc" -v "d:\Text\"

blb2txt -f "d:\Docs\book.doc" -out "d:\Text\book.txt"

blb2txt -f "d:\Docs\*.doc" -f "d:\Docs\*.rtf" -v "d:\Text\" -e utf8 --replace-empty-lines

blb2txt -f "d:\Docs\*.*" -v "d:\Text\" -p "Dokument" -u

blb2txt -f "d:\Docs\1.doc" -v "d:\Text\" -p "Dokument" -a -n 20 -t 100

blb2txt -f "d:\Book\book.fb2" -v "d:\Text\" -p "Buch" -k "KAPITEL" -k "BAND"

blb2txt -f "d:\Book\book.epub" -v "d:\Text\" -p "Buch" -r "###"

blb2txt -f "d:\Book\book.fb2" -v "d:\Text\" -p "%Number% - %Header%" -c -m 1024

blb2txt -f "d:\Docs\book.doc" -v "d:\Text\" -d "d:\rex\rules.rex" -d "d:\dic\rules.dic" --remove-spaces --remove-linebreaks

blb2txt -i -o --remove-spaces --remove-linebreaks --replace-empty-lines


*** Konfigurationsdatei ***

Die Befehlszeilen-Optionen k�nnen als Konfigurationsdatei "blb2txt.cfg" im Ordner der Konsolen-Anwendung gespeichert werden. 

Beispiel f�r eine Konfigurationsdatei:
=====================
-f d:\Docs\*.rtf
-f d:\Books\*.epub
-f d:\Books\*.fb2
-v d:\Text
-b
-n 1
-t 25
-e utf8
-d d:\Dict\rules.bxd
--remove-spaces
--remove-linebreaks
--replace-empty-lines
=====================

Das Programm kann Optionen von der Konfigurationsdatei und der Kommandozeile kombinieren.


*** Operationen ***

Ausf�hrungsreihenfolge der Operationen:

1. Text von Eingabedatei(en) extrahieren.
2. Text formatieren: Leerzeichen, Zeilenumbr�che usw. entfernen (wenn Option gew�hlt).
3. Dateien in einer Datei zusammenfassen (wenn Option gew�hlt).
4. Text splitten (wenn Option gew�hlt).
5. Regeln f�r Aussprache-Korrektur anwenden (wenn Option gew�hlt).
6. Ausgabedatei(en) speichern.


*** Lizenzart ***

Sie k�nnen Software f�r nichtkommerzielle Zwecke verwenden und vertreiben. F�r die kommerzielle Nutzung oder den Vertrieb ben�tigen Sie die Genehmigung des Urheberrechtsinhabers.

###