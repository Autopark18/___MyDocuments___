Balabolka (utilitaire d'extraction de texte du fichier), version 1.76
Copyright (c) 2013-2019 Ilya Morozov
All Rights Reserved

WWW : http://balabolka.site/fr/btext.htm
E-mail : crossa@list.ru

Licence : Freeware
Syst�me d'exploitation : Microsoft Windows XP/Vista/7/8/10


Le programme permet d'extraire le texte de diff�rents types de fichiers.
L�extrait du texte peut �tre combin� en un seul fichier et/ou fractionn� en plusieurs fichiers.
Les r�gles de correction de la prononciation de Balabolka peuvent �tre appliqu�es au texte.
Les formats suivants sont soutenus : AZW, AZW3, CHM, DjVu (DjVu+OCR), DOC, DOCX, EPUB, FB2 (FB2.ZIP, FBZ), FB3, HTML, LIT, MHT, MOBI, ODP, ODS, ODT, PDB, PDF, PPT, PPTX, PRC, RTF, TCR, TXT, WPD, WRI, XLS, XLSX.
The IFilter interface will be used for files with unknown extensions.


*** Ligne de commande ***

blb2txt [options ...]


*** Param�tres de ligne de commande ***

-f <nom_de_fichier>
   Le nom du fichier d'entr�e ou le masque pour un groupe de fichiers d'entr�e. La ligne de commande peut contenir quelques options [-f].

-v <nom_de_dossier>
   Le nom du dossier de sortie pour un fichier texte enregistr�.

-p <texte>
   Sp�cifie le mod�le pour le nom de fichier de sortie (par exemple, � Document texte �). En cas d'absence, le nom du fichier d'entr�e est utilis�.
   Utilisez la variable %FirstLine% pour ins�rer la premi�re ligne de texte dans le nom du fichier de sortie.
   Use the %Header% variable to insert the chapter title to the output file name.
   Utilisez la variable %Number% pour modifier la position du num�ro de s�quence dans le nom du fichier de sortie.

-out <nom_de_fichier>
   Sets the full name for output file. The option is recommended to specify only when the utility is used as a part of other software.
   If the utility is used for custom document import,  the external program runs the utility from a command line and passes the full name of a text file to create.

-i
   Lit le texte de flux d'entr�e standard (STDIN). Si l'option est sp�cifi�e, l'option [-f] est ignor�e.

-o
   Enregistre le texte dans le flux de sortie standard (STDOUT). Si l'option est sp�cifi�e, les options [-v] et [-p] sont ignor�es.

-u
   Combine les fichiers texte en un seul fichier de sortie.

-b
   Ajoute le num�ro de s�quence devant le nom de fichier de sortie.

-a
   Ajoute le num�ro de s�quence apr�s le nom de fichier de sortie.

-n <nombre_int�gral>
   Sp�cifie le num�ro de s�quence de d�part pour les fichiers de sortie. La valeur par d�faut est 1.

-e <encodage>
   Sp�cifie l'encodage pour les fichiers de sortie (� ansi �, � utf8 � ou � unicode �). La valeur par d�faut est � ansi �.

-t <nombre_int�gral>
   Sp�cifie le mode de fractionnement du texte : fichier d�une taille sp�cifi�e. Le nombre d�signe la taille en kilobytes.

-k <mot-cl�>
   Fractionne le texte sur le mot-cl� sp�cial dans le fichier d'entr�e. L'option est sensible � la casse. La ligne de commande peut contenir plusieurs options [-k].

-r <mot-cl�>
   Fractionne le texte sur le mot-cl� et le supprime des fichiers de sortie. L'option est sensible � la casse. La ligne de commande peut contenir plusieurs options [-r].

-w
   Fractionne le texte sur deux lignes vides cons�cutives.

-l
   Fractionne le texte sur les lignes o� toutes les lettres sont majuscules.

-c
   Splits text by a table of contents. The application extracts positions of chapter beginnings from the input file (if the file contains such information).

-toc
   Generates a table of contents and splits text. The application splits the extracted text by keywords (like � chapitre � or � tome �).
   If the option is used together with the option [-c], the application will try to extract a table of contents from the document; if it fails, a new table of contents will be generated.

-m <nombre_int�gral>
   Ignores the chapter beginning if the size of the previous chapter is less than the specified value (in characters). The option is used together with the option [-c] or [-toc].

-hh <texte>
   Inserts text in front of headings (for example: ## Chapter 1).

-d <nom_de_fichier>
   Utilise un dictionnaire pour la correction de la prononciation (fichiers *.BXD, *.DIC ou *.REX). La ligne de commande peut contenir plusieurs options [-d].

-if
   Utilise l'interface IFilter pour extraire le texte. Si ce type de format est absent dans le syst�me, la m�thode par d�faut sera utilis�e par l'application.

-g <nom_de_dossier>
   Sets the name of output folder for saving of images from a document.

-cvr <nom_de_dossier>
   Sets the name of output folder for saving of a book cover image.

-pwd <texte>
   Sp�cifie le mot de passe pour extraire le texte des fichiers PDF crypt�s.

-? ou -h
   Affiche la liste des options de ligne de commande disponibles.

--remove-spaces ou -rs
   Supprime les espaces superflues (deux ou plusieurs espaces de suite, espaces ins�cables).

--remove-hyphens ou -rh
   Supprime tous les traits d'union � la fin des lignes.

--remove-linebreaks ou -rl
   Supprime les sauts de ligne � l'int�rieur des paragraphes.

--remove-empty-lines ou -rm
   Supprime les lignes vides.

--replace-empty-lines ou -rp
   Remplace plusieurs lignes vides d�une seule ligne vide.

--remove-square-brackets ou -rsb
   Supprime le texte entre [crochets].

--remove-curly-brackets ou -rcb
   Supprime le texte entre {accolades}.

--remove-angle-brackets ou -rab
   Supprime le texte entre <chevrons>.

--remove-round-brackets ou -rrb
   Removes text in (round brackets).

--remove-comments ou -rc
   Remove comments. Single-line comments start with // and continue until the end of the line. Multiline comments start with /* and end with */.

--remove-page-numbers ou -rpn
   Removes page numbers (it may be useful for DjVu/PDF files).

--fix-ocr-errors ou -ocr
   Corrige les erreurs d'OCR (reconnaissance optique de caract�res) (pour les langues avec les alphabets cyrilliques uniquement).

--fix-letter-spacing ou -ls
   Fixes letter-spacing in words (for example: s p a c e, _w_o_r_d).

--skip-summary ou -ss
   Skips a summary, when the application extracts text from FB2/FB3 files.

--skip-notes ou -sn
   Skips notes, when the application extracts text from DOCX/FB2/FB3/ODT files.

--include-notes <nombre_int�gral> ou -in <nombre_int�gral>
   Includes notes inside text, when the application extracts text from DOCX/FB2/FB3/ODT files.
   Possible values for the integer parameter:
   0 - removes links to notes from text,
   1 - keeps default positions of notes inside text (this value is used by default),
   2 - places notes at the end of sentences,
   3 - places notes at the end of paragraphs.

--csv-comma
   Columns are separated by a comma, when the application extracts data from XLS/XLSX/ODS files (default delimiter for CSV files).

--csv-semicolon
   Columns are separated by a semicolon, when the application extracts data from XLS/XLSX/ODS files.

--csv-space
   Columns are separated by a blank space, when the application extracts data from XLS/XLSX/ODS files.

--csv-tab
   Columns are separated by a tab, when the application extracts data from XLS/XLSX/ODS files.

--csv-double-quote
   Uses double-quote characters, if a field must be quoted (export from XLS/XLSX/ODS files).

--csv-single-quote
   Uses single-quote characters, if a field must be quoted (export from XLS/XLSX/ODS files).

--eml-save <nom_de_dossier>
   Extracts attachments from EML files and saves to a specified folder.

--eml-att
   Extracts the list of attachments from EML files (names of files attached to the message).

--eml-cc
   Extracts the header field "Cc" from EML files ("carbon copy"; it specifies additional recipients of the message).

--eml-date <date_format>
   Extracts the header field "Date" from EML files (the local time and date when the message was composed and sent). A date format are defined by specifiers (such as "d", "m", "y", etc.). For example: "dd.mm.yyyy hh:nn:ss".

--eml-from
   Extracts the header field "From" from EML files (the email address, and optionally the name of the author).

--eml-org
   Extracts the header field "Organization" from EML files (the name of the organization through which the sender of the message has net access).

--eml-rt
   Extracts the header field "Reply-To" from EML files (the address for replies to go to).

--eml-subj
   Extracts the header field "Subject" from EML files (the subject of the message).

--eml-to
   Extracts the header field "To" from EML files (the email address, and optionally the name of the message's recipient).


*** Exemples ***

blb2txt -f "d:\Docs\book.doc" -v "d:\Text\"

blb2txt -f "d:\Docs\book.doc" -out "d:\Text\book.txt"

blb2txt -f "d:\Docs\*.doc" -f "d:\Docs\*.rtf" -v "d:\Text\" -e utf8 --replace-empty-lines

blb2txt -f "d:\Docs\*.*" -v "d:\Text\" -p "Document" -u

blb2txt -f "d:\Docs\1.doc" -v "d:\Text\" -p "Document" -a -n 20 -t 100

blb2txt -f "d:\Book\book.fb2" -v "d:\Text\" -p "Livre" -k "CHAPITRE" -k "TABLE DES MATI�RES"

blb2txt -f "d:\Book\book.epub" -v "d:\Text\" -p "Livre" -r "###"

blb2txt -f "d:\Book\book.fb2" -v "d:\Text\" -p "%Number% - %Header%" -c -m 1024

blb2txt -f "d:\Docs\book.doc" -v "d:\Text\" -d "d:\rex\rules.rex" -d "d:\dic\rules.dic" --remove-spaces --remove-linebreaks

blb2txt -i -o --remove-spaces --remove-linebreaks --replace-empty-lines


*** Fichier de configuration ***

Les options de ligne de commande peuvent �tre enregistr�es en tant que fichier de configuration � blb2txt.cfg � dans le m�me dossier que l'application console.

Exemple de fichier de configuration :
=====================
-f d:\Docs\*.rtf
-f d:\Books\*.epub
-f d:\Books\*.fb2
-v d:\Text
-b
-n 1
-t 25
-e utf8
-d d:\Dict\rules.bxd
--remove-spaces
--remove-linebreaks
--replace-empty-lines
=====================

Le programme peut combiner les options du fichier de configuration et celles de la ligne de commande.


*** Op�rations ***

L�ordre d'ex�cution des op�rations :

1.  Extraire le texte de fichier(s).
2.  Formater le texte : supprimer les espaces superflues, sauts de ligne, etc. (si l'option est sp�cifi�e).
3.  Combiner le texte en un seul fichier (si l'option est sp�cifi�e).
4.  Fractionner le texte (si l'option est sp�cifi�e).
5.  Appliquer les r�gles de correction de la prononciation (si l'option est sp�cifi�e).
6.  Enregistrer le(s) fichier(s) de sortie sur disque.


*** Licence ***

Droits d'utilisation non commerciale de l�application :
- personnes physiques � sans restriction,
- personnes morales � avec les restrictions stipul�es dans l'Accord de Licence du logiciel Balabolka.

L�utilisation commerciale du logiciel demande l'autorisation du d�tenteur du copyright.

###