Balabolka (tekstin j�sennin), versio 1.76
Copyright (c) 2013-2019 Ilya Morozov
All Rights Reserved

WWW: http://balabolka.site/fi/btext.htm
E-mail: crossa@list.ru

Lisenssi: Freeware
K�ytt�j�restelm�: Microsoft Windows XP/Vista/7/8/10


Sovelluksen tarkoitus on j�sent�� teksti erilaisista tiedostoista.
Saatu teksti voidaan yhdist�� samaan tiedostoon tai jakaa muutamiin pienempiin tiedostoihin.
Tekstin kohdalta voi soveltaa Balabolkan ��nestyskorjaussanakirjoja.
Sovellus yll�pit�� seuraavat tiedostotyypit: AZW, AZW3, CHM, DjVu (DjVu+OCR), DOC, DOCX, EPUB, FB2 (FB2.ZIP, FBZ), FB3, HTML, LIT, MHT, MOBI, ODP, ODS, ODT, PDB, PDF, PPT, PPTX, PRC, RTF, TCR, TXT, WPD, WRI, XLS, XLSX.
The IFilter interface will be used for files with unknown extensions.


*** Komentorivi ***

blb2txt [options ...]


*** Komentoriviparametrit ***

-f <tiedoston_nimi>
   Tiedoston nimi tai kaava, josta saadaan teksti�. Komentoon voi sis�lty� muutama [-f] -parametri.

-v <kansion_nimi>
   Tallenna j�sennetty teksti mainittuun kansioon. 

-p <tekstin_rivi>
   Tallenna j�sennetty teksti tallentamiseen tarkoitettuun tiedostoon (esim. tekstitiedostoon). Jos t�t� parametria ei k�ytet�, maalitiedoston nimi on sama kuin l�hteen.
   Use the %FirstLine% variable to insert the first line of text to the output file name.
   Use the %Header% variable to insert the chapter title to the output file name.
   Use the %Number% variable to change the position of the sequence number inside the output file name.

-out <tiedoston_nimi>
   Sets the full name for output file. The option is recommended to specify only when the utility is used as a part of other software.
   If the utility is used for custom document import,  the external program runs the utility from a command line and passes the full name of a text file to create.

-i
   Lue teksti standardisy�tt�virrassa (STDIN) oleva teksti. Jos parametri on mainittu, parametri [-f] on v�litt�m�tt�.

-o
   kirjoita teksti standarditulostevirtaan (STDOUT). Jos parametri on mainittu, parametrit [-v] ja [-p] ovat v�litt�m�tt�.

-u
   Yhdist� teksti muutamista tiedostoista yhteen.

-b
   Lis�� j�rjestysnumero tiedostonimen alkuun.

-a
   Lis�� j�rjestysnumero tiedostonimen loppuun.

-n <luku>
   M��r�� ensimm�inen j�rjestysnumero. Oletusnumero on 1.

-e <merkist�>
   M��r�� j�sennetyn tekstin merkist� ("ansi", "utf8" tai "unicode"). Oletusmerkist� on "ansi".

-t <luku>
   M��r�� tekstin j�sent�mistapa: k�yt� m��r�tty tiedostokoko. Luku tarkoittaa tiedoston kilotavum��r��.

-k <avainsana>
   M��r�� tekstin j�sent�mistapa: etsi avainsana. Parametri on merkkikokoriippuvainen. Komentoon voi sis�lty� muutama [-k] -parametri.

-r <avainsana>
   Jaa teksti avainsanalla ja poista t�m� tekstist�. Parametri on merkkikokoriippuvainen. Komentoon voi sis�lty� muutama [-r] -parametri.

-w
   M��r�� tekstin j�sent�mistapa: etsi kaksi per�kk�ist� tyhj�� rivi�.

-l
   M��r�� tekstin j�sent�mistapa: etsi rivi, jossa kaikki kirjaimet ovat suuraakkosia.

-c
   Splits text by a table of contents. The application extracts positions of chapter beginnings from the input file (if the file contains such information).

-toc
   Generates a table of contents and splits text. The application splits the extracted text by keywords (like "chapter" or "volume").
   If the option is used together with the option [-c], the application will try to extract a table of contents from the document; if it fails, a new table of contents will be generated.

-m <luku>
   Ignores the chapter beginning if the size of the previous chapter is less than the specified value (in characters). The option is used together with the option [-c] or [-toc].

-hh <tekstin_rivi>
   Inserts text in front of headings (for example: ## Chapter 1).
 
-d <tiedoston_nimi>
   K�yt� sanakirja ��nt�myksen korjaamiseksi (tiedostolaajennus *.BXD, *.DIC tai *.REX). Komentoon voi sis�lty� muutama [-d] -parametri.

-if
   Uses IFilter interface to extract text. If this fails, the default method will be used by the application.

-g <kansion_nimi>
   Sets the name of output folder for saving of images from a document.

-cvr <kansion_nimi>
   Sets the name of output folder for saving of a book cover image.

-pwd <tekstin_rivi>
   Sets the password for the encrypted PDF files.

-? tai -h
   N�yt� kaikki mahdolliset parametrit.

--remove-spaces tai -rs
   Poista ylim��r�iset v�lit (kaksi tai enemm�n per�kk�ist� v�li� tai kiinte�t v�lit).

--remove-hyphens tai -rh
   Poista rivien lopussa olevat yhdysmerkit.

--remove-linebreaks tai -rl
   Poista kappaleiden sis�iset rivinvaihdot.

--remove-empty-lines tai -rm
   Poista kaikki tyhj�t rivit.

--replace-empty-lines tai -rp
   Korvaa muutama tyhj� rivi yhdell� tyhj�ll� rivill�.

--remove-square-brackets tai -rsb
   Poista teksti [hakasulkujen] sis�lt�.

--remove-curly-brackets tai -rcb
   Poista teksti {aaltosuluista} sis�lt�.

--remove-angle-brackets tai -rab
   Poista teksti <kulmasulkujen> sis�lt�.

--remove-round-brackets tai -rrb
   Removes text in (round brackets).

--remove-comments tai -rc
   Remove comments. Single-line comments start with // and continue until the end of the line. Multiline comments start with /* and end with */.

--remove-page-numbers tai -rpn
   Removes page numbers (it may be useful for DjVu/PDF files).
 
--fix-ocr-errors tai -ocr
   Korjaa tekstintunnistuksen aikana syntyneet virheet (sovellettava vain kyrillist� kirjaimistoa k�ytett�viss� kieliss�).

--fix-letter-spacing tai -ls
   Fixes letter-spacing in words (for example: s p a c e, _w_o_r_d).

--skip-summary tai -ss
   Skips a summary, when the application extracts text from FB2/FB3 files.

--skip-notes tai -sn
   Skips notes, when the application extracts text from DOCX/FB2/FB3/ODT files.

--include-notes <luku> tai -in <luku>
   Includes notes inside text, when the application extracts text from DOCX/FB2/FB3/ODT files.
   Possible values for the integer parameter:
   0 - removes links to notes from text,
   1 - keeps default positions of notes inside text (this value is used by default),
   2 - places notes at the end of sentences,
   3 - places notes at the end of paragraphs.

--csv-comma
   Columns are separated by a comma, when the application extracts data from XLS/XLSX/ODS files (default delimiter for CSV files).

--csv-semicolon
   Columns are separated by a semicolon, when the application extracts data from XLS/XLSX/ODS files.

--csv-space
   Columns are separated by a blank space, when the application extracts data from XLS/XLSX/ODS files.

--csv-tab
   Columns are separated by a tab, when the application extracts data from XLS/XLSX/ODS files.

--csv-double-quote
   Uses double-quote characters, if a field must be quoted (export from XLS/XLSX/ODS files).

--csv-single-quote
   Uses single-quote characters, if a field must be quoted (export from XLS/XLSX/ODS files).

--eml-save <kansion_nimi>
   Extracts attachments from EML files and saves to a specified folder.

--eml-att
   Extracts the list of attachments from EML files (names of files attached to the message).

--eml-cc
   Extracts the header field "Cc" from EML files ("carbon copy"; it specifies additional recipients of the message).

--eml-date <date_format>
   Extracts the header field "Date" from EML files (the local time and date when the message was composed and sent). A date format are defined by specifiers (such as "d", "m", "y", etc.). For example: "dd.mm.yyyy hh:nn:ss".

--eml-from
   Extracts the header field "From" from EML files (the email address, and optionally the name of the author).

--eml-org
   Extracts the header field "Organization" from EML files (the name of the organization through which the sender of the message has net access).

--eml-rt
   Extracts the header field "Reply-To" from EML files (the address for replies to go to).

--eml-subj
   Extracts the header field "Subject" from EML files (the subject of the message).

--eml-to
   Extracts the header field "To" from EML files (the email address, and optionally the name of the message's recipient).


*** Esimerkkej� ***

blb2txt -f "d:\Docs\book.doc" -v "d:\Text\"

blb2txt -f "d:\Docs\book.doc" -out "d:\Text\book.txt"

blb2txt -f "d:\Docs\*.doc" -f "d:\Docs\*.rtf" -v "d:\Text\" -e utf8 --replace-empty-lines

blb2txt -f "d:\Docs\*.*" -v "d:\Text\" -p "Tiedosto" -u

blb2txt -f "d:\Docs\1.doc" -v "d:\Text\" -p "Tiedosto" -a -n 20 -t 100

blb2txt -f "d:\Book\book.fb2" -v "d:\Text\" -p "Kirja" -k "KAPPALE" -k "SIS�LT�"

blb2txt -f "d:\Book\book.epub" -v "d:\Text\" -p "Kirja" -r "###"

blb2txt -f "d:\Book\book.fb2" -v "d:\Text\" -p "%Number% - %Header%" -c -m 1024

blb2txt -f "d:\Docs\book.doc" -v "d:\Text\" -d "d:\rex\rules.rex" -d "d:\dic\rules.dic" --remove-spaces --remove-linebreaks

blb2txt -i -o --remove-spaces --remove-linebreaks --replace-empty-lines


*** Konfiguraatiotiedosto ***

Parametrit voi tallentaa "blb2txt.cfg" -nimiseen konfiguraatiotiedostoon, joka sijaitsee sovelluksen kansiossa.

Tiedoston sis�llyksen esimerkki:
=====================
-f d:\Docs\*.rtf
-f d:\Books\*.epub
-f d:\Books\*.fb2
-v d:\Text
-b
-n 1
-t 25
-e utf8
-d d:\Dict\rules.bxd
--remove-spaces
--remove-linebreaks
--replace-empty-lines
=====================

Sovellus voi yhdist�� konfiguraatiotiedostossa olevat ja komentorivin parametrit.


*** Toiminta ***

Sovellus toimii seuraavasti:

1.  Tekstin tiedostosta j�sent�minen.
2.  Tekstin muotoilu: ylim��r�isten v�lien ja rivinvaihtojen poistaminen jne. (jos vastaavat parametrit sis�ltyv�t komentoon).
3.  Teksti samaan tiedostoon yhdist�minen (jos vastaava parametri sis�ltyy komentoon).
4.  Teksti jakaminen (jos vastaavat parametrit sis�ltyv�t komentoon).
5.  ��nt�myksen korjauss��nt�jen soveltaminen (jos vastaavat parametrit sis�ltyv�t komentoon).
6.  Tiedoston levylle tallentaminen.


*** Lisenssi ***

Sovelluksen kaupallinen k�ytt�oikeus:
- toiminimelle rajoituksetta;
- oikeushenkil�it� koskevat rajoitukset on mainittu Balabolkan lisenssisopimuksessa.

Sovelluksen kaupallinen k�ytt� sallittu ainoastaan oikeudenomistajan luvasta.

###